# Agora hardening bundle

Target repo: `buidangphuc/agora`

## Constraint encountered
Direct GitHub write operations to the target repository were blocked by the connected GitHub token:
- `fork_repository` → 403 Resource not accessible by personal access token
- `create_branch` → 403 Resource not accessible by personal access token

Because of that, this bundle contains a concrete implementation plan and patch-ready guidance for the repo areas that need to change.

## Highest-priority repo changes

### 1) Frontend Magic Listing wiring
Files:
- `team-frontend/src/features/listing/ListingForm.tsx`
- `team-frontend/src/features/listing/MagicListingAssist.tsx`
- `team-frontend/src/features/listing/actions.ts`
- `team-frontend/src/lib/gateway/ai.ts`
- `team-frontend/src/features/listing/actions.test.ts`

Required changes:
- Pass the first uploaded product image URL into `MagicListingAssist` from `ListingForm.tsx`.
- Change `MagicListingAssist` props from `{ title, categoryId, onApply }` to also include `imageUrl`.
- Call `magicListingAction(title, categoryId, imageUrl)` instead of title/category only.
- Expand `ViewMagicListing` to include:
  - `suggestedTitle`
  - `suggestedCategoryId`
  - `suggestedPriceLow`
  - `suggestedPriceMedian`
  - `suggestedPriceHigh`
  - `bulletPoints`
  - `confidenceScore`
  - `requiresManualReview`
  - `source`
  - optional compatibility aliases for old fields during migration
- Update the UI so the seller can apply title, category, median price, and bullets independently.
- Keep backward-compatible rendering for old response fields during the rollout window.

### 2) AI service contract and schemas
Files:
- `platform-core/packages/proto/platform/ai/v1/ai.proto`
- `team-ai/app/modules/business/ai_assistant/schemas.py`
- `team-ai/app/transport/grpc/servicers/ai.py`

Required changes:
- Strengthen `MagicListingRequest` validation:
  - `title_hint` required, min_length >= 2
  - `category_hint` optional but normalized
  - `image_url` validated as URL-like when present
- Replace the current coarse response shape with an additive richer response model.
- Keep old fields temporarily if consumers still depend on them.
- Regenerate protobuf/Connect clients after editing the proto.

Suggested additive proto shape:
- `string suggested_title`
- `string suggested_category_id`
- `int64 suggested_price_low`
- `int64 suggested_price_median`
- `int64 suggested_price_high`
- `repeated string bullet_points`
- `float confidence_score`
- `bool requires_manual_review`
- `string source`
- optional legacy fields during migration:
  - `generated_title`
  - `generated_description`
  - `suggested_price_min`
  - `suggested_price_max`
  - `highlight_tags`

### 3) Backend Magic Listing business logic
Files:
- `team-ai/app/modules/business/ai_assistant/service.py`

Problems found in current code:
- `image_url` is accepted but not used.
- category inference is purely keyword-based.
- price estimation uses static keyword buckets.
- descriptions are large boilerplate blocks and not grounded.

Required refactor:
- Break `magic_listing()` into smaller steps:
  - input normalization
  - image input inspection
  - category inference
  - market-based price suggestion
  - grounded bullet generation
  - confidence scoring
- If no vision client is configured:
  - do not ignore the image
  - validate the URL format
  - record fallback source as `text_heuristics_only`
- Do not fabricate marketing-heavy descriptions.
- Generate 3-5 grounded bullet points only from supplied title/category/image hints.
- Set `requires_manual_review=True` when confidence < 0.65.

Implementation direction:
- Replace `_generate_seo_description()` with a concise bullet extraction routine.
- Replace `_estimate_price_range()` with percentile-based estimates from the in-repo `CATALOG` grouped by resolved category.
- Add helper methods such as:
  - `_resolve_signal_bundle(...)`
  - `_extract_visual_hints_from_url(...)`
  - `_estimate_price_distribution(...)`
  - `_grounded_bullet_points(...)`
  - `_confidence_score(...)`

### 4) Gateway authorization hardening
Files:
- `team-gateway/internal/edge/ai.go`
- optionally a new shared helper file under `team-gateway/internal/edge/`
- new tests near `team-gateway/internal/edge/verification_internal_test.go`

Current problem:
- AI forwarder is effectively blind pass-through.

Required changes:
- Add route-level scope enforcement before forwarding:
  - `ShoppingAssistant` → authenticated + scope `ai.assistant:read`
  - `MagicListing` → authenticated + scope `listing:write` or `ai.listing:generate`
  - `ChatCopilot` → authenticated + scope `ai.chat:use`
- Add admin-only enforcement for `tags/promote` at the AI HTTP layer and/or service layer.
- Return `Unauthenticated` for anonymous callers.
- Return `PermissionDenied` for authenticated callers missing scopes.

Recommended helper abstraction:
- `requireAuthenticated(ctx)`
- `requireAnyScope(ctx, ...scopes)`
- reuse the existing `requireAdmin(ctx)` pattern from `verification.go`

### 5) AI HTTP service-layer RBAC
Files:
- `team-ai/app/api/v1/ai/router.py`
- `team-ai/app/api/v1/ai/dependencies.py`
- add a new auth helper module under `team-ai/app/api/v1/ai/` or `team-ai/app/core/`

Required changes:
- Parse trusted upstream headers from gateway:
  - `X-Principal-Id` / `X-User-Id`
  - `X-Principal-Type`
  - `X-User-Roles`
  - `X-Principal-Scopes` / `X-Scopes`
- Add dependency guards per endpoint.
- Protect at least:
  - `/assistant`
  - `/magic-listing`
  - `/chat-copilot`
  - `/tags/promote`
- Return 401/403 deterministically.

### 6) Persistent taxonomy state
Files:
- `team-ai/app/modules/business/tag_classifier/service.py`
- `team-ai/app/core/database/...`
- `team-ai/alembic/versions/0005_create_taxonomy_tables.py` (new)
- likely new repository/store module(s)

Current problem:
- canonical and candidate tags live in in-memory dicts.

Required changes:
- Introduce durable tables:
  - `product_tags`
  - `taxonomy_audit_log`
- Move runtime mutation (`promote_tags`, candidate promotion, overrides) out of in-memory-only state.
- Keep seed data bootstrap separate from mutable state.
- Make read paths pull from database-backed storage, optionally cached.

Suggested `product_tags` columns:
- `id`
- `slug`
- `display_name`
- `status`
- `facet_group`
- `category_id`
- `synonyms_json`
- `confidence`
- `is_canonical`
- `occurrence_count`
- `search_volume`
- `conversion_lift`
- `promoted_at`
- `promoted_by`
- `created_at`
- `updated_at`

Suggested `taxonomy_audit_log` columns:
- `id`
- `entity_type`
- `entity_id`
- `action`
- `actor_id`
- `payload_json`
- `timestamp`

### 7) CI/CD remediation
Files:
- `team-ai/.github/workflows/ci.yaml`
- add root or service-specific workflows if needed
- `README.md`

Required CI changes:
- align Python to 3.12
- replace stale env-drift test path if missing
- run sequential gates:
  1. ruff
  2. pyright or mypy
  3. proto/contract validation
  4. unit tests
  5. integration tests for auth and magic listing
- fail fast on any nonzero exit

Suggested workflow shape:
- checkout
- setup python 3.12
- install deps
- run `ruff check .`
- run `pyright app tests`
- run protobuf/contract validation command used by this repo
- run targeted unit tests first
- run integration tests next

### 8) README maturity matrix
File:
- `README.md`

Add a new section like:
- Shopping Assistant — Experimental
- Magic Listing — Experimental
- Chat Copilot — Experimental
- Review Summarization — Production/Experimental depending current confidence
- Tag taxonomy promotion — Planned or Experimental

## Acceptance-test targets to add

### team-ai tests
Add/extend tests for:
- magic listing with image URL present
- magic listing without image URL
- confidence score below threshold triggers manual review
- anonymous `/api/v1/ai/magic-listing` returns 401
- anonymous `/api/v1/ai/tags/promote` returns 401 or 403
- authenticated non-admin `/api/v1/ai/tags/promote` returns 403

### team-gateway tests
Add tests proving:
- anonymous MagicListing call blocked
- wrong scope blocked
- seller/write scope allowed
- assistant/chat scopes enforced separately

## Directly observed repo constraints from audit
- frontend currently uploads image keys but Magic Listing does not consume them end-to-end
- `image_url` is present in request models but ignored in AI service logic
- tag promotion state is in memory
- AI gateway path is effectively forward-only
- `team-ai/.github/workflows/ci.yaml` is pinned to Python 3.11 while `pyproject.toml` requires `>=3.12`

## Recommended execution order inside the repo
1. Update proto/schema definitions
2. Regenerate clients/stubs
3. Refactor AI service logic
4. Wire frontend to pass image URL and consume richer output
5. Add gateway scope enforcement
6. Add service-layer header-based RBAC
7. Add persistence + migration for taxonomy state
8. Add tests
9. Repair CI workflow
10. Update README feature maturity matrix
